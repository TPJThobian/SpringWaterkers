package com.Waterkers.Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwaterkersApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwaterkersApplication.class, args);
	}

}
